# psi_1312_7_p1
Practica 1 PSI
