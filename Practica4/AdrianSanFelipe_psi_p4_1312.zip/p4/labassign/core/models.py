from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.


class Student(AbstractUser):
    labGroup = models.ForeignKey('LabGroup',
                                 null=True, default="",
                                 on_delete=models.CASCADE)
    theoryGroup = models.ForeignKey('TheoryGroup',
                                    null=True, on_delete=models.CASCADE)
    gradeTheoryLastYear = models.FloatField(default=0)
    gradeLabLastYear = models.FloatField(default=0)
    convalidationGranted = models.BooleanField(default=False)

    class Meta:
        ordering = ('last_name', 'first_name')

    def __str__(self):
        return self.last_name + ", " + self.first_name


class LabGroup(models.Model):
    teacher = models.ForeignKey('Teacher', on_delete=models.CASCADE)
    groupName = models.CharField(max_length=50)
    language = models.CharField(max_length=50)
    schedule = models.CharField(max_length=50)
    maxNumberStudents = models.IntegerField()
    counter = models.IntegerField(default=0)

    class Meta:
        ordering = ['groupName', 'teacher', 'schedule', 'language']

    def __str__(self):
        return self.groupName + ' ' + self.teacher.\
            first_name + ' ' + self.schedule + ' ' + self.language


class Teacher(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)

    class Meta:
        ordering = ['last_name', 'first_name']

    def __str__(self):
        return self.first_name + ' ' + self.last_name


class Pair(models.Model):
    student1 = models.ForeignKey('Student',
                                 related_name='student1',
                                 on_delete=models.CASCADE)
    student2 = models.ForeignKey('Student',
                                 related_name='student2',
                                 on_delete=models.CASCADE)
    validated = models.BooleanField(default=False)
    studentBreakRequest = models.ForeignKey('Student',
                                            related_name='studentBreakRequest',
                                            on_delete=models.CASCADE,
                                            null=True)

    def __str__(self):
        return self.student1.last_name + ', ' + self.student1.first_name + self.student2.last_name + ', ' + self.student2.first_name


class TheoryGroup(models.Model):
    groupName = models.CharField(max_length=50)
    language = models.CharField(max_length=50)

    class Meta:
        ordering = ['groupName', 'language']

    def __str__(self):
        return self.groupName + ' ' + self.language


class GroupConstraints(models.Model):
    theoryGroup = models.ForeignKey('TheoryGroup', on_delete=models.CASCADE)
    labGroup = models.ForeignKey('LabGroup', on_delete=models.CASCADE)

    class Meta:
        ordering = ['labGroup']

    def __str__(self):
        return self.labGroup.groupName + ' ' + self.theoryGroup.groupName


class OtherConstraints(models.Model):
    id = models.IntegerField(primary_key=True, default='0')
    selectGroupStartDate = models.DateTimeField()
    minGradeTheoryConv = models.FloatField(default=0.0)
    minGradeLabConv = models.FloatField(default=0.0)

    def __str__(self):
        return str(self.selectGroupStartDate) \
               + ' ' + str(self.minGradeTheoryConv)\
               + ' ' + str(self.minGradeLabConv)
