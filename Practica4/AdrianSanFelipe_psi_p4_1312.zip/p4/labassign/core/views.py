from django.shortcuts import render
from django.shortcuts import redirect
from django.urls import reverse
from django.contrib.auth import authenticate, login
from django.utils import timezone
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.db.models import Q
from core.forms import PairForm, GroupForm, BreakPairForm
from core.models import (OtherConstraints, Pair, Student,
                         LabGroup)

# Create your views here.


# Funcion index
def index(request):
    return render(request, 'core/index.html')


# Funcion convalidation
def convalidation(request):
    # obtenemos el usuario de la sesion actual
    # y lo almacenamos en la variable user
    user = request.user
    # En la consola, printeamos su id (para depuracion)
    print(user.id)
    # obtenemos las otherConstraints
    otherConstraints = OtherConstraints.objects.filter(id=1).get()
    # En la consola, printeamos otherConstraints (para depuracion)
    print(otherConstraints)
    # Buscamos si el id del estudiante se encuentra en una pareja
    student1 = Pair.objects.filter(student1_id=user.id)
    print(student1)
    student2 = Pair.objects.filter(student2_id=user.id, validated=True)
    print(student2)
    # almacenamos los valores en un diccionario
    context_dict = {'otherConstraints': otherConstraints,
                    'student1': student1, 'student2': student2}
    # Si el usuario esta autenticado
    if request.user.is_authenticated:
        # Preguntamos si el alumno esta en una pareja
        if Pair.objects.filter(student1_id=user.id) or\
                Pair.objects.filter(student2_id=user.id, validated=True):
            # Si esta en una pareja, no se puede convalidar
            print("Este alumno está en una pareja.")
            return render(request, 'core/convalidation.html',
                          context=context_dict)
        # Si el alumno no esta en ninguna pareja:
        else:
            # Si sus notas cumplen las condiciones the otherConstraints
            if user.gradeLabLastYear >= otherConstraints.minGradeLabConv\
                    and user.gradeTheoryLastYear >=\
                    otherConstraints.minGradeTheoryConv:
                # Hace un update de convalidationGranted y lo pone a True
                Student.objects.filter(id=user.id).\
                    update(convalidationGranted=True, labGroup="")
                # Devolvemos el diccionario a la pagina de convalidacion
                return render(request, 'core/convalidation.html',
                              context=context_dict)
            # Si las notas no se cumplen, no se devuelve el diccionario
            else:
                return render(request, 'core/convalidation.html')
    # Si el usuario no esta autenticado:
    else:
        return render(request, 'core/login.html')


# Funcion home
def home(request):
    # obtenemos el usuario de la sesion actual
    # y lo almacenamos en la variable user
    user = request.user
    # Con los siguientes try y except lo que buscamos es si
    # el usuario actual pertenece a alguna pareja, para asi
    # devolver las variables en un diccionario a la pagina de home
    # y mostrarlas
    try:
        pairs = Pair.objects.filter(student1_id=user.id).first()
    except pairs.doesNotExist:
        context_dict = {}
    try:
        pairs2 = Pair.objects.\
            filter(student2_id=user.id, validated=True).first()
        context_dict = {'pairs': pairs, 'pairs2': pairs2}
    except pairs.doesNotExist:
        context_dict = {}
    # Si el usuario esta autenticado:
    if request.user.is_authenticated:
        # Devolvemos la pagina con el diccionario
        return render(request, 'core/home.html',
                      context=context_dict)
    # Si el usuario no esta autenticado:
    else:
        return render(request, 'core/login.html')


# Funcion applygroup
def applygroup(request):
    # Hasta la linea 113 creamos las varibles de user con el usuario
    # actual, un diccionario vacio, una lista de IDs con la funcion set,
    # una varibles cons con los datos de OtherConstraints, una variable
    # para almacenar la fecha actual y mas tarde almacenamos estas dos
    # en el diccionario anterior
    user = request.user
    context_dict = {}
    listID = set()
    cons = OtherConstraints.objects.get(id=1)
    print(cons)
    dt = timezone.now()
    print(dt)
    context_dict = {'cons': cons, 'dt': dt}
    # Si el usuario esta autenticado y el metodo es POST:
    if request.user.is_authenticated:
        if request.method == 'POST':
            # Creamos una variable form con GroupForm de forms.py
            form = GroupForm(user, listID, request.POST)
            # Si la variable form es valida:
            if form.is_valid():
                # Almacena en una variable el valor del laboratorio (su id)
                labGroupID = form['myLabGroup'].value()
                # Almacena en una variable el valor de obtener ese mismo id
                lab = LabGroup.objects.get(id=labGroupID)
                # Si la fecha de cons es menor o igual a la fecha de dt:
                if cons.selectGroupStartDate <= dt:
                    # Almacenas en pair con un filtro de Q, que sirve para
                    # encapsular una colección de argumentos de palabras clave
                    pair = Pair.objects.filter((Q(student1=user)
                                                | Q(student2=user)),
                                               Q(validated=True)).first()
                    # Si el alumno no esta en ningun par:
                    if not pair:
                        # Si el laboratorio no está lleno:
                        if lab.counter < lab.maxNumberStudents:
                            # Añade el id del laboratorio al usuario
                            Student.objects.filter(id=user.id).\
                                update(labGroup=labGroupID)
                            # Suma 1 al contador del laboratorio
                            LabGroup.objects.filter(id=labGroupID).\
                                update(counter=lab.counter + 1)
                    # Si el alumno está en un par:
                    else:
                        # Hace lo mismo pero metiendo a los dos estudiantes
                        if lab.counter <= lab.maxNumberStudents - 1:
                            Student.objects.filter(id=pair.student1.id).\
                                update(labGroup=labGroupID)
                            Student.objects.filter(id=pair.student2.id).\
                                update(labGroup=labGroupID)
                            # Y en vez de sumar 1 suma 2
                            LabGroup.objects.filter(id=labGroupID).\
                                update(counter=lab.counter + 2)
        # Almacena el formulario en form y lo introduce en el diccionario
        else:
            form = GroupForm(user, listID)
            context_dict["form"] = form
        # devuelve el diccionario a la pagina applygroup
        return render(request, 'core/applygroup.html', context_dict)
    # Si el usuario no esta autenticado vuelve a la pagina login
    else:
        return render(request, 'core/login.html')


# Funcion applypair
def applypair(request):
    # Hasta la linea 172 creamos las varibles de user con el id del usuario
    # actual, un diccionario vacio, una lista de IDs con la funcion set y
    # una varible booleana
    user = request.user.id
    selectedPair = False
    context_dict = {}
    listID = set()
    # Si el usuario esta autenticado y el metodo es POST:
    if request.user.is_authenticated:
        if request.method == 'POST':
            # Creamos una variable form con PairForm de forms.py
            form = PairForm(user, listID, request.POST)
            # Si la variable form es valida:
            if form.is_valid():
                # Obtenemos el id del segundo miembro de la pareja
                secondMemberID = form['secondMemberGroup'].value()
                # stud es el usuario actual
                stud = Student.objects.get(id=request.user.id)
                # Imprimimos para depuracion
                print(stud)
                # stud2 es el segundo miembro de la pareja
                stud2 = Student.objects.get(id=secondMemberID)
                # Imprimimos para depuracion
                print(stud2)
                # Si el par de los dos estudiantes existe:
                if Pair.objects.filter(student1=stud2, student2=stud).exists():
                    # Crea el par, lo valida, asigna a los
                    # dos el mismo grupo de laboratorio
                    # y lo guarda
                    pair = Pair.objects.get(student1=stud2, student2=stud)
                    # Imprimimos para depuracion
                    print(pair)
                    pair.validated = True
                    stud.labGroup = stud2.labGroup
                    stud.save()
                    pair.save()
                # Si el par no existia previamente:
                else:
                    if not Pair.objects.filter(student1=stud).exists():
                        # Crea el par con los dos estudiantes pero NO lo valida
                        Pair.objects.create(student1=stud,
                                            student2=stud2,
                                            validated=False)
                    else:
                        # La variable booleana la ponemos a true
                        # y almacenamos en un diccionario
                        # para pasarsela a la pagina web
                        selectedPair = True
                        context_dict = {'selectedPair': selectedPair}
        # Almacena el formulario en form y lo introduce en el diccionario
        else:
            form = PairForm(user, listID)
            context_dict["form"] = form
        # devuelve el diccionario a la pagina applypair
        return render(request, 'core/applypair.html', context_dict)
    # Si el usuario no esta autenticado vuelve a la pagina login
    else:
        return render(request, 'core/login.html')


# Funcion breakpair
def breakpair(request):
    # Hasta la linea 230 creamos las varibles de user con el usuario
    # actual, un diccionario vacio, una lista de IDs con la funcion set
    user = request.user
    context_dict = {}
    listID = set()
    # Si el usuario esta autenticado y el metodo es POST:
    if user.is_authenticated:
        if request.method == 'POST':
            # Creamos una variable form de la forma BreakPairForm de forms.py
            form = BreakPairForm(user, listID, request.POST)
            # Si la variable form es valida:
            if form.is_valid():
                # Obtenemos el id del estudiante
                pair = form['myPair'].value()
                stud = Student.objects.get(id=request.user.id)
                # Printeamos en consola para depuracion
                print(stud)
                stud2 = None
                # Si el par con el estudiante 1 existe:
                if Pair.objects.filter(id=pair, student1=stud).exists():
                    stud2 = Pair.objects.get(id=pair, student1=stud).student2
                # Si el par con el estudiante 2 existe:
                elif Pair.objects.filter(id=pair, student2=stud).exists():
                    stud2 = Pair.objects.get(id=pair, student2=stud).student1
                # Si no existe un estudiante 2
                # devuelve un error con ese mismo estudiante
                if not stud2:
                    context_dict = {'error': stud2}
                    return render(request, 'core/breakpair.html',
                                  context=context_dict)
                # Si los dos estudiantes existen:
                if Student.objects.filter(id=stud.id, labGroup=None).exists()\
                        and Student.objects.\
                        filter(id=stud2.id, labGroup=None).exists():
                    # Si el par estaba sin validar lo borra
                    if Pair.objects.filter(id=pair, validated=False).exists():
                        Pair.objects.filter(id=pair, validated=False).delete()
                    # Si el par estaba validado:
                    elif Pair.objects.filter(id=pair, validated=True).exists():
                        # Si el par tenia el breakresquest como none:
                        if Pair.objects.filter(id=pair, validated=True,
                                               studentBreakRequest=None).\
                                exists():
                            p = Pair.objects.get(id=pair, validated=True,
                                                 studentBreakRequest=None)
                            p.studentBreakRequest = stud
                            p.save()
                        # Si el par tenia el breakrequest
                        # distinto a none lo borra:
                        else:
                            Pair.objects.\
                                filter(id=pair, validated=True).delete()
        # Almacena un error en el diccionario
        # y lo devuelve a la pagina breakpair
        else:
            context_dict = {'error': user}
            form = BreakPairForm(user, listID)
            context_dict["form"] = form
        return render(request, 'core/breakpair.html', context=context_dict)
    # Si el usuario no estaba autenticado
    # entonces le devuelve a login
    else:
        return render(request, 'core/login.html')


# Funcion login
def user_login(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(username=username, password=password)
            if user:
                if user.is_active:
                    login(request, user)
                    return redirect(reverse('core:home'))
                else:
                    return HttpResponse("Your account is disabled.")
            else:
                return HttpResponse("Invalid login details supplied.")
        else:
            return render(request, 'core/login.html')
    else:
        return HttpResponse("Ya estas autenticado. No puedes"
                            " acceder a esta pagina mientras lo estes.")


# Funcion logout
@login_required
def user_logout(request):
    logout(request)
    return redirect(reverse('core:index'))
