from django.urls import path
from core import views

app_name = 'core'

urlpatterns = [
    path('', views.index, name='index'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('convalidation/', views.convalidation, name='convalidation'),
    path('home/', views.home, name='home'),
    path('applygroup/', views.applygroup, name='applygroup'),
    path('applypair/', views.applypair, name='applypair'),
    path('breakpair/', views.breakpair, name='breakpair'),

]
