import django
import os

from core.models import (OtherConstraints, Pair, Student)
from django.utils import timezone
from datetime import timedelta
from labassign.settings import BASE_DIR
from django.test import SimpleTestCase
django.setup()
pathToProject = BASE_DIR
os.environ.setdefault('DJANGO_SETTINGS_MODULE',
                      'labassign.settings')


class QueryTestUsers(SimpleTestCase):
    allow_database_queries = True

    def test_create_student1000(self):
        try:
            Student.objects.get(id=1000)
        except:
            user_1000 = Student.objects.create(id=1000,
                                               first_name="Alumno1",
                                               last_name="Alumno1",
                                               username=1234)
            user_1000.set_password("1234")
            user_1000.save()
            self.assertEqual(user_1000, Student.objects.get(id=1000))

    def test_create_student1001(self):
        try:
            Student.objects.get(id=1001)
        except:
            user_1001 = Student.objects.create(id=1001,
                                               first_name="Alumno2",
                                               last_name="Alumno2",
                                               username=4321)
            user_1001.set_password("4321")
            user_1001.save()
            self.assertEqual(user_1001, Student.objects.get(id=1001))

    def test_create_pair(self):
        user_1000 = Student.objects.create(id=1000,
                                           first_name="Alumno1",
                                           last_name="Alumno1",
                                           username=1234)
        user_1000.set_password("1234")
        user_1000.save()
        self.assertEqual(user_1000, Student.objects.get(id=1000))
        user_1001 = Student.objects.create(id=1001,
                                           first_name="Alumno2",
                                           last_name="Alumno2",
                                           username=4321)
        user_1001.set_password("4321")
        user_1001.save()
        self.assertEqual(user_1001, Student.objects.get(id=1001))
        student1 = Student.objects.get(id=1000)
        student2 = Student.objects.get(id=1001)
        Pair.objects.get_or_create(student1=student1,
                                   student2=student2, validated=False)

    def test_student1_1000(self):
        student1_1000 = Pair.objects.get(student1=1000)
        print(str(student1_1000))

    def test_student1_validated(self):
        Pair.objects.filter(student1=1000).update(validated=True)


class QueryTestOtherConstraints(SimpleTestCase):
    allow_database_queries = True

    def test_OtherConstraints(self):
        dt = timezone.now()
        td = timedelta(days=1)
        my_date = dt + td
        otherconstraints = OtherConstraints. \
            objects.create(selectGroupStartDate=my_date)
        if str(otherconstraints) < str(timezone.now()):
            print(str(otherconstraints) + " es una fecha en el pasado.")
        else:
            print(str(otherconstraints) + " es una fecha en el futuro.")
