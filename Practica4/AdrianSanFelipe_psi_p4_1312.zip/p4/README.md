# psi_1312_p4
Practica 4 de PSI.
Flake8 arreglado en mis archivos(menos en algunas líneas de populate.py ya que sino no funcionaría).
Funciones de views.py comentadas.
Intentado subir la nueva versión de la aplicación a Heroku de mil formas, pero no ha habido manera(y no entiendo muy bien por qué ya que no cambió nada).
Añadida guía para el usuario con imágenes.
