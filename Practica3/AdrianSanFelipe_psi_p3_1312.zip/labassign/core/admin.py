from django.contrib import admin
from core.models import Student, LabGroup, Teacher, Pair, TheoryGroup, GroupConstraints, OtherConstraints


class LabGroupAdmin(admin.ModelAdmin):
	list_display = ('group_name', 'teacher', 'language', 'schedule', 'maxNumberStudents', 'counter')


class GroupConstraintsAdmin(admin.ModelAdmin):
	list_display = ('theoryGroup', 'labGroup')

# Register your models here.


admin.site.register(Student)
admin.site.register(LabGroup)
admin.site.register(Teacher)
admin.site.register(Pair)
admin.site.register(TheoryGroup)
admin.site.register(GroupConstraints)
admin.site.register(OtherConstraints)
