from django.shortcuts import render
from django.shortcuts import redirect
from django.urls import reverse
from django.contrib.auth import authenticate, login
from django.utils import timezone
from datetime import datetime, timedelta
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.db.models import Q
from core.forms import PairForm, GroupForm
from core.models import (OtherConstraints, Pair, Student,
                         GroupConstraints, TheoryGroup,
                         LabGroup, Teacher)

# Create your views here.


def index(request):
    return render(request, 'core/index.html')


def convalidation(request):
    user = request.user
    print(user.id)
    otherConstraints = OtherConstraints.objects.filter(id=1).get()
    print(otherConstraints)
    student1 = Pair.objects.filter(student1_id=user.id)
    print(student1)
    student2 = Pair.objects.filter(student2_id=user.id, validated=True)
    print(student2)
    context_dict = {'otherConstraints': otherConstraints, 'student1': student1, 'student2': student2}
    if request.user.is_authenticated:
        if Pair.objects.filter(student1_id=user.id) or Pair.objects.filter(student2_id=user.id, validated=True):
            print("Este alumno está en una pareja.")
            return render(request, 'core/convalidation.html', context=context_dict)
        else:
            if user.gradeLabLastYear >= otherConstraints.minGradeLabConv and user.gradeTheoryLastYear >= otherConstraints.minGradeTheoryConv:
                Student.objects.filter(id=user.id).update(convalidationGranted=True, labGroup="")
                return render(request, 'core/convalidation.html', context=context_dict)
            else:
                return render(request, 'core/convalidation.html')
    else:
        return render(request, 'core/login.html')


def home(request):
    user = request.user
    try:
        pairs = Pair.objects.filter(student1_id=user.id).first()
    except pairs.doesNotExist:
        context_dict = {}
    try:
        pairs2 = Pair.objects.filter(student2_id=user.id, validated=True).first()
        context_dict = {'pairs': pairs, 'pairs2': pairs2}
    except pairs.doesNotExist:
        context_dict = {}
    if request.user.is_authenticated:
        return render(request, 'core/home.html', context=context_dict)
    else:
        return render(request, 'core/login.html')


def applygroup(request):
    user = request.user
    context_dict = {}
    listID = set()
    cons = OtherConstraints.objects.get(id=1)
    print(cons)
    dt = timezone.now()
    print(dt)
    context_dict = {'cons': cons, 'dt': dt}
    if request.user.is_authenticated:
        if request.method == 'POST':
            form = GroupForm(user, listID, request.POST)
            if form.is_valid():
                labGroupID = form['myLabGroup'].value()
                lab = LabGroup.objects.get(id=labGroupID)
                if cons.selectGroupStartDate <= dt:
                    pair = Pair.objects.filter((Q(student1=user) | Q(student2=user)), Q(validated=True)).first()
                    if not pair:
                        if lab.counter < lab.maxNumberStudents:
                            Student.objects.filter(id=user.id).update(labGroup=labGroupID)
                            LabGroup.objects.filter(id=labGroupID).update(counter=lab.counter + 1)
                    else:
                        if lab.counter <= lab.maxNumberStudents - 1:
                            Student.objects.filter(id=pair.student1.id).update(labGroup=labGroupID)
                            Student.objects.filter(id=pair.student2.id).update(labGroup=labGroupID)
                            LabGroup.objects.filter(id=labGroupID).update(counter=lab.counter + 2)
        else:
            form = GroupForm(user, listID)
            context_dict["form"] = form
        return render(request, 'core/applygroup.html', context_dict)
    else:
        return render(request, 'core/login.html')


def applypair(request):
    user = request.user.id
    selectedPair = False
    context_dict = {}
    listID = set()
    if request.user.is_authenticated:
        if request.method == 'POST':
            form = PairForm(user, listID, request.POST)
            if form.is_valid():
                secondMemberID = form['secondMemberGroup'].value()
                stud = Student.objects.get(id=request.user.id)
                print(stud)
                stud2 = Student.objects.get(id=secondMemberID)
                print(stud2)
                if Pair.objects.filter(student1=stud2, student2=stud).exists():
                    pair = Pair.objects.get(student1=stud2, student2=stud)
                    print(pair)
                    pair.validated = True
                    stud.labGroup = stud2.labGroup
                    stud.save()
                    pair.save()
                else:
                    if not Pair.objects.filter(student1=stud).exists():
                        Pair.objects.create(student1=stud,
                                            student2=stud2,
                                            validated=False)
                    else:
                        selectedPair = True
                        context_dict = {'selectedPair': selectedPair}
        else:
            form = PairForm(user, listID)
            context_dict["form"] = form
        return render(request, 'core/applypair.html', context_dict)
    else:
        return render(request, 'core/login.html')


def breakpair(request):
    if request.user:
        return render(request, 'core/breakpair.html')
    else:
        return render(request, 'core/login.html')


def user_login(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(username=username, password=password)
            if user:
                if user.is_active:
                    login(request, user)
                    return redirect(reverse('core:home'))
                else:
                    return HttpResponse("Your account is disabled.")
            else:
                return HttpResponse("Invalid login details supplied.")
        else:
            return render(request, 'core/login.html')
    else:
        return HttpResponse("Ya estas autenticado. No puedes acceder a esta pagina mientras lo estes.")


@login_required
def user_logout(request):
    logout(request)
    return redirect(reverse('core:index'))
