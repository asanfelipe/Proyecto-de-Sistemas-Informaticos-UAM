from django import forms
from django.contrib.auth.models import User
from core.models import (OtherConstraints, Pair, Student,
                         GroupConstraints, TheoryGroup,
                         LabGroup, Teacher)


class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = User
        fields = ('username', 'email', 'password')


class GroupForm(forms.Form):
    myLabGroup = forms.ModelChoiceField(queryset=None, label="Selecciona el grupo de lab:")

    def __init__(self, user, listID, *args, **kwargs):
        super(forms.Form, self).__init__(*args, **kwargs)
        groupsCant = GroupConstraints.objects.filter(theoryGroup=user.theoryGroup).values_list('theoryGroup', flat=True)
        groupsCant = [entry for entry in groupsCant]
        listID = listID.union(set(groupsCant))
        self.fields['myLabGroup'].queryset = GroupConstraints.objects.filter(theoryGroup__in=listID)


class PairForm(forms.Form):
    secondMemberGroup = forms.ModelChoiceField(queryset=None, label="Selecciona el segundo miembro de la pareja:")

    def __init__(self, user, listID, *args, **kwargs):
        super(forms.Form, self).__init__(*args, **kwargs)
        listID.add(user)

        pairValidated1 = Pair.objects.filter(validated=True).values_list('student1', flat=True)
        pairValidated1 = [entry for entry in pairValidated1]
        listID = listID.union(set(pairValidated1))

        pairValidated2 = Pair.objects.filter(validated=True).values_list('student2', flat=True)
        pairValidated2 = [entry for entry in pairValidated2]
        listID = listID.union(set(pairValidated2))

        self.fields['secondMemberGroup'].queryset = Student.objects.all().exclude(id__in=listID)
