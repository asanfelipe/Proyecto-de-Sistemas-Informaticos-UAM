# Populate database
# This file has to be placed within the
# core/management/commands directory in your project.
# If that directory doesn't exist, create it.
# The name of the script is the name of the custom command,
# that is, populate.py.
#
# execute python manage.py populate
import csv
import collections
import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'labassign.settings')
django.setup()

from datetime import timedelta
from django.utils import timezone
from django.core.management.base import BaseCommand
from core.models import OtherConstraints, Pair, Student, GroupConstraints, TheoryGroup, LabGroup, Teacher


# The name of this class is not optional must be Command
# otherwise manage.py will not process it properly
#
# Teachers, groups and constraints
# will be hardcoded in this file.
# Students will be read from a cvs file
# last year grade will be obtained from another cvs file
class Command(BaseCommand):
    # helps and arguments shown when command python manage.py help populate
    # is executed.
    help = """populate database
           """

    def add_arguments(self, parser):
        parser.add_argument('model', type=str, help="""
        model to  update:
        all -> all models
        teacher
        labgroup
        theorygroup
        groupconstraints
        otherconstrains
        student (require csv file)
        studentgrade (require different csv file,
        update only existing students)
        pair
        """)
        parser.add_argument('studentinfo', type=str, help="""CSV file with student information
        header= NIE, DNI, Apellidos, Nombre, Teoría
        if NIE or DNI == 0 skip this entry and print a warning""")
        parser.add_argument('studentinfolastyear', type=str, help="""CSV file with student information
        header= NIE,DNI,Apellidos,Nombre,Teoría, grade lab, grade the
        if NIE or DNI == 0 skip this entry and print a warning""")

    # handle is another compulsory name, do not change it"
    def handle(self, *args, **kwargs):
        model = kwargs['model']
        cvsStudentFile = kwargs['studentinfo']
        cvsStudentFileGrades = kwargs['studentinfolastyear']
        # clean database
        if model == 'all':
            self.cleanDataBase()
        if model == 'teacher' or model == 'all':
            self.teacher()
        if model == 'labgroup' or model == 'all':
            self.labgroup()
        if model == 'theorygroup' or model == 'all':
            self.theorygroup()
        if model == 'groupconstraints' or model == 'all':
            self.groupconstraints()
        if model == 'otherconstrains' or model == 'all':
            self.otherconstrains()
        if model == 'student' or model == 'all':
            self.student(cvsStudentFile)
        if model == 'studentgrade' or model == 'all':
            self.studentgrade(cvsStudentFileGrades)
        if model == 'pair' or model == 'all':
            self.pair()

    def cleanDataBase(self):
        Student.objects.all().delete()
        Teacher.objects.all().delete()
        LabGroup.objects.all().delete()
        Pair.objects.all().delete()
        TheoryGroup.objects.all().delete()
        GroupConstraints.objects.all().delete()
        OtherConstraints.objects.all().delete()

    def teacher(self):
        "create teachers here"
        teacherD = [
            {'id': 1,  # 1261, L 18:00, 1271 X 18-20
             'first_name': 'No',
             'last_name': 'Asignado1'},
            {'id': 2,  # 1262 X 18-20, 1263/1273 V 17-19
             'first_name': 'No',
             'last_name': 'Asignado4'},
            {'id': 3,  # 1272 V 17-19, 1291 L 18-20
             'first_name': 'Julia',
             'last_name': 'Diaz Garcia'},
            {'id': 4,  # 1292/1251V 17:00
             'first_name': 'Alvaro',
             'last_name': 'del Val Latorre'},
            {'id': 5,  # 1201 X 18:00
             'first_name': 'Roberto',
             'last_name': 'Marabini Ruiz'}]

        for teacher in teacherD:
            t = Teacher.objects.get_or_create(id=teacher['id'],
                                              first_name=teacher['first_name'],
                                              last_name=teacher['last_name'])[0]
            t.save()

    def labgroup(self):
        "add labgroups"
        maxNumberStudents = 23
        labgroupD = [
            {'id': 1201,
             'teacher': 5,
             'groupName': '1201',
             'schedule': 'Miércoles/Wednesday 18-20',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1261,
             'groupName': '1261',
             'teacher': 1,
             'schedule': 'Lunes/Monday 18-20',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1262,
             'teacher': 2,
             'groupName': '1262',
             'schedule': 'Miércoles/Wednesday 18-20',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1263,
             'teacher': 2,
             'groupName': '1263',
             'schedule': 'Viernes/Friday 17-19',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1271,
             'teacher': 1,
             'groupName': '1271',
             'schedule': 'Miércoles/Wednesday 18-20',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1272,
             'teacher': 3,
             'groupName': '1272',
             'schedule': 'Viernes/Friday 17-19',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1291,
             'teacher': 3,
             'groupName': '1291',
             'schedule': 'Lunes/Monday 18-20',
             'language': 'inglés/English',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1292,
             'teacher': 4,
             'groupName': '1292',
             'schedule': 'Viernes/Friday 17-19',
             'language': 'inglés/English',
             'maxNumberStudents': maxNumberStudents}]

        for labgroup in labgroupD:
            lbgrp = LabGroup.objects.get_or_create(id=labgroup['id'],
                                                   teacher=Teacher.objects.get_or_create(id=labgroup['teacher'])[0],
                                                   groupName=labgroup['groupName'],
                                                   schedule=labgroup['schedule'],
                                                   language=labgroup['language'],
                                                   maxNumberStudents=labgroup['maxNumberStudents'])[0]
            lbgrp.save()

    def theorygroup(self):
        "add theorygroups"
        theorygroupD = [
            {'id': 126,
                'groupName': '126',
                'language': 'español/Spanish'},
            {'id': 127,
                'groupName': '127',
                'language': 'español/Spanish'},
            {'id': 129,
                'groupName': '129',
                'language': 'inglés/English'},
            {'id': 120,
                'groupName': '120',
                'language': 'español/Spanish'},
            {'id': 125,
                'groupName': '125',
                'language': 'inglés/English'}]

        for theorygroup in theorygroupD:
            thrgrp = TheoryGroup.objects.get_or_create(id=theorygroup['id'],
                                                       groupName=theorygroup['groupName'],
                                                       language=theorygroup['language'])[0]
            thrgrp.save()

    def groupconstraints(self):
        "add group constrints"
        """ Follows which laboratory groups (4th column
            may be choosen by which theory groups (2nd column)
            theoryGroup: 126, labGroup: 1261
            theoryGroup: 126, labGroup: 1262
            theoryGroup: 126, labGroup: 1263
            theoryGroup: 127, labGroup: 1271
            theoryGroup: 127, labGroup: 1272
            theoryGroup: 120, labGroup: 1201
            theoryGroup: 129, labGroup: 1291
            theoryGroup: 125, labGroup: 1292"""
        groupconstraintsD = [
            {'theoryGroup': 126,
                'labGroup': 1261},
            {'theoryGroup': 126,
                'labGroup': 1262},
            {'theoryGroup': 126,
                'labGroup': 1263},
            {'theoryGroup': 126,
                'labGroup': 1263},
            {'theoryGroup': 127,
                'labGroup': 1271},
            {'theoryGroup': 127,
                'labGroup': 1272},
            {'theoryGroup': 120,
                'labGroup': 1201},
            {'theoryGroup': 129,
                'labGroup': 1291},
            {'theoryGroup': 125,
                'labGroup': 1292}]

        for groupconstraints in groupconstraintsD:
            grpCns = GroupConstraints.objects.get_or_create(id=groupconstraints['labGroup'],
                                                            theoryGroup=TheoryGroup.objects.get_or_create(groupName=groupconstraints['theoryGroup'])[0],
                                                            labGroup=LabGroup.objects.get_or_create(groupName=groupconstraints['labGroup'])[0])[0]
            grpCns.save()

    def pair(self):
        "create a few valid pairs"
        """ create two requests
            1000 -> 1100
            1001 -> 1001
            create three verified groups
            1010 - 1110
            1011 - 1111
            1012 - 1112
        """
        pairD = {}
        pairD = collections.OrderedDict()
        pairD[1000] = {'student2': 1100, 'validated': False}
        pairD[1001] = {'student2': 1101, 'validated': False}
        pairD[1010] = {'student2': 1110, 'validated': True}
        pairD[1011] = {'student2': 1111, 'validated': True}
        pairD[1012] = {'student2': 1112, 'validated': True}

        st1 = Student.objects.get(id=1000)
        st2 = Student.objects.get(id=pairD[1000]['student2'])
        p = Pair.objects.get_or_create(student1=st1, student2=st2, validated=pairD[1000]['validated'])[0]
        p.save()

        st1 = Student.objects.get(id=1001)
        st2 = Student.objects.get(id=pairD[1001]['student2'])
        p = Pair.objects.get_or_create(student1=st1, student2=st2, validated=pairD[1001]['validated'])[0]
        p.save()

        st1 = Student.objects.get(id=1010)
        st2 = Student.objects.get(id=pairD[1010]['student2'])
        p = Pair.objects.get_or_create(student1=st1, student2=st2, validated=pairD[1010]['validated'])[0]
        p.save()

        st1 = Student.objects.get(id=1011)
        st2 = Student.objects.get(id=pairD[1011]['student2'])
        p = Pair.objects.get_or_create(student1=st1, student2=st2, validated=pairD[1011]['validated'])[0]
        p.save()

        st1 = Student.objects.get(id=1012)
        st2 = Student.objects.get(id=pairD[1012]['student2'])
        p = Pair.objects.get_or_create(student1=st1, student2=st2, validated=pairD[1012]['validated'])[0]
        p.save()

    def otherconstrains(self):
        today = timezone.now()
        tomorrow = timedelta(days=1)
        date = today + tomorrow
        ocns = OtherConstraints.objects.get_or_create(
            id=1,
            selectGroupStartDate=date,
            minGradeTheoryConv=3.0,
            minGradeLabConv=7.0,
        )[0]
        ocns.save()

    def student(self, csvStudentFile):
        # read csv file
        # structure NIE	DNI	Apellidos	Nombre	group-Teoría
        # remove pass and ADD CODE HERE
        with open('19-edat_psi.csv', 'r') as file:
            reader = csv.reader(file, delimiter=',')
            comienzo = 0
            for row in reader:
                if comienzo == 0:
                    comienzo += 1
                else:
                    studentthisyear = Student.objects.get_or_create(id=1000+comienzo-1,
                        username=row[0],
                        last_name=row[2], first_name=row[3],
                        theoryGroup=TheoryGroup.objects.get(groupName=row[4]),
                        labGroup=None)[0]
                    studentthisyear.set_password(row[1])
                    studentthisyear.save()
                    comienzo += 1

    def studentgrade(self, cvsStudentFileGrades):
        # read csv file
        # structure NIE	DNI	Apellidos	Nombre	group-Teoría	grade-practicas	gradeteoria
        # remove pass and ADD CODE HERE
        with open('19-edat_2_psi.csv', 'r') as file:
            reader = csv.reader(file, delimiter=',')
            comienzo = 0
            for row in reader:
                if comienzo == 0:
                    comienzo += 1
                else:
                    studentlastyear = Student.objects.get_or_create(id=1000+comienzo-1,
                        username=row[0],
                        last_name=row[2], first_name=row[3],
                        theoryGroup=TheoryGroup.objects.get(groupName=row[4]),
                        labGroup=None)[0]
                    studentlastyear.set_password(row[1])
                    if studentlastyear:
                        studentlastyear.gradeLabLastYear=row[5]
                        studentlastyear.gradeTheoryLastYear=row[6]
                        studentlastyear.save()
                        comienzo += 1


print("Populate.py ejecutado correctamente.")