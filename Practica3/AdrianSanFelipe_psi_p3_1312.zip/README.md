# psi_1312_p3
Practica 3 de PSI
